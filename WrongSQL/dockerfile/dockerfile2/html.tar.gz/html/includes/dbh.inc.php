 <?php 
$dbServername="localhost";
$dbUsername="root";
$dbPassword="123456";
$dbName="loginsystem";
$conn=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
 ?>
