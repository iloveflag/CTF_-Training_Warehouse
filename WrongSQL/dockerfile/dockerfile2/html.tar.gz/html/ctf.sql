create database loginsystem;

use loginsystem;

create table users(
id int(5) not null PRIMARY KEY AUTO_INCREMENT,
user_email varchar(30) not null,
user_uid varchar(20) not null,
user_pwd varchar(60) not null

);

create database z3333333;


use z3333333;
create table 3333333z(
fl4gbest varchar(60) not null
);

INSERT INTO 3333333z(fl4gbest)VALUES('flag{C0ngratulations_T0_extractvalue}');